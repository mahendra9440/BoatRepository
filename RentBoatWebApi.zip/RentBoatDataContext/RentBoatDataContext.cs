﻿
using System;
using System.Collections.Generic;
using System.Text;
using BoatRental;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace RentBoatDataContext
{
    public class RentBoatDataContext : DbContext
    {
        public virtual DbSet<BoatModel> BoatModels { get; set; }
        public virtual DbSet<BoatRentDetails> BoatRentDetails { get; set; }
        public virtual DbSet<CustomerModel> CustomerModels { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UsePostgreSql(@"host=server;database=test;user id=postgres;");
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<BoatModel>(entity =>
            {
                entity.HasKey(e => e.BoatId);

                entity.ToTable("boattable", "public");

                entity.Property(e => e.BoatId).HasColumnName("boatid");

                entity.Property(e => e.BoatName)
                    .HasColumnName("boatname")
                    .HasColumnType("varchar")
                    .HasMaxLength(50);

                entity.Property(e => e.HourlyAmount)
                    .HasColumnName("hourlyamount")
                    .HasColumnType("int");

                entity.Property(e => e.CustomerId)
                    .HasColumnName("customerid")
                    .HasColumnType("int");
            });

            modelBuilder.Entity<CustomerModel>(entity =>
            {
                entity.HasKey(e => e.CustID)
                    .HasName("");

                entity.ToTable("CustomerDetails", "public");

                entity.Property(e => e.CustID).HasColumnName("custid");

                entity.Property(e => e.CustName)
                    .HasColumnName("custname")
                    .HasColumnType("varchar")
                    .HasMaxLength(50);


                entity.Property(e => e.CustProof)
                    .HasColumnName("custproof")
                    .HasColumnType("varchar")
                    .HasMaxLength(1000);

                entity.Property(e => e.CustAddress)
                      .HasColumnName("custaddress")
                      .HasColumnType("varchar")
                      .HasMaxLength(1000);
            });
            modelBuilder.Entity<BoatRentDetails>(entity =>
            {
                entity.HasKey(e => e.BRID)
                    .HasName("rentid");


                entity.Property(e => e.BID).HasColumnName("bid");

                entity.Property(e => e.CID).HasColumnName("cid");

                entity.Property(e => e.RentAmount).HasColumnName("rentalamount");

                entity.Property(e => e.isActive)
                    .HasColumnName("isActive")
                    .HasColumnType("bit");


                entity.Property(e => e.NoHours).HasColumnName("noOfHours");

                entity.Property(e => e.ToDate)
                    .HasColumnName("todate")
                    .HasColumnType("datetime");
                
                entity.Property(e => e.FromDate)
                                    .HasColumnName("fromdate")
                                    .HasColumnType("datetime");

                });

        }

    }

}
