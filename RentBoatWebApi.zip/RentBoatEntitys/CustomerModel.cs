﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BoatRental
{
   public class CustomerModel
    {
        public CustomerModel()
        {

        }
        public int CustID { get; set; }
        public string CustName { get; set; }
        public string CustProof { get; set; }
        public string CustAddress { get; set; }
    }
}
