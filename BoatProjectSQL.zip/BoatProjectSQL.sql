select * from RentalDetails
select * from boattable
select * from CustomerDetails

