﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BoatRental
{
   public  class BoatRentDetails
    {
        public BoatRentDetails()
        {

        }
        public int BRID { get; set; }
        public int CID { get; set; }
        public int BID { get; set; }
        public int  RentAmount { get; set; }
        public int NoHours { get; set; }
        public bool isActive { get; set; }
        public DateTime? FromDate { get; set; }
        public DateTime? ToDate { get; set; }
    }

}
