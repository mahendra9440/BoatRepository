﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using BoatRental;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace RentBoatWebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BoatRentalController : Controller
    {
        private readonly IBoatRentalRepository _boatRentalRepository;
        public BoatRentalController(IBoatRentalRepository boatRentalRepository)
        {
            _boatRentalRepository = boatRentalRepository;
        }

        [HttpGet("getBoats")]
        public ActionResult getBoats()
        {
            var Boats = _boatRentalRepository.GetBoats();
            return Json(Boats);
        }

        [HttpGet("getCustomers")]
        public ActionResult getCustomers()
        {
            var Boats = _boatRentalRepository.GetCustomers();
            return Json(Boats);
        }

        [HttpPost("CreateBoat")]
        public ActionResult CreateBoat([FromBody] BoatModel boatModel)
        {
            var Boats = _boatRentalRepository.CreateNewBoat(boatModel);
            return Json(Boats);
        }

        [HttpPost("BookBoat")]
        public ActionResult BookBoat([FromBody] BoatRentDetails boatRentDetails)
        {
            var Boats = _boatRentalRepository.BookBoatForCustomer(boatRentDetails.BID, boatRentDetails.CID, boatRentDetails.NoHours);
            return Json(Boats);
        }
    }
}
