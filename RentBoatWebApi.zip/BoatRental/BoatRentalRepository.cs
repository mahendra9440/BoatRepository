﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using RentBoatDataContext;


namespace BoatRental
{
    public class BoatRentalRepository : IBoatRentalRepository
    {
        private readonly RentBoatDataContext.RentBoatDataContext _rentBoatDataContext;
        public BoatRentalRepository()
        {
            _rentBoatDataContext = new RentBoatDataContext.RentBoatDataContext();
        }
        public string BookBoatForCustomer(int BoatId, int CustId, int NoOfHours)
        {
            var custDetails = _rentBoatDataContext.CustomerModels.Where(x => x.CustID == CustId).FirstOrDefault();
            if (custDetails == null) return "Customer Does not exist";
            var BoatDetails = _rentBoatDataContext.BoatModels.Where(x => x.BoatId == BoatId).FirstOrDefault();
            if (BoatDetails == null) return "Boat Does not exists";
            var Boatvalidation = _rentBoatDataContext.BoatRentDetails.Where(x => x.BID == BoatId && x.isActive == false).FirstOrDefault();
            if (Boatvalidation == null) return "Boat already in engagged...";

            BoatRentDetails rentDetails = new BoatRentDetails()
            {
                BID = BoatId,
                CID = CustId,
                FromDate = DateTime.Now,
                NoHours = NoOfHours,
                RentAmount = NoOfHours * BoatDetails.HourlyAmount,
                isActive = false
            };
            _rentBoatDataContext.BoatRentDetails.Add(rentDetails);
            return _rentBoatDataContext.SaveChanges() > 0 ? "Boat Booked sucessfully" : "Somthing went wrong";
        }

        public string CreateNewBoat(BoatModel boat)
        {
            if (boat.HourlyAmount <= 0) return "Sholud enter hourly amount from boat";
            BoatModel boa1t = new BoatModel()
            {
                BoatName = boat.BoatName,
                HourlyAmount = boat.HourlyAmount,
            };
            _rentBoatDataContext.BoatModels.Add(boa1t);
            return _rentBoatDataContext.SaveChanges() > 0 ? "Boat Created sucessfully" : "Somthing went wrong";
        }

        public List<BoatModel> GetBoats()
        {
           return _rentBoatDataContext.BoatModels.ToList();
        }

        public List<CustomerModel> GetCustomers()
        {
            return _rentBoatDataContext.CustomerModels.ToList();
        }
    }
    public interface IBoatRentalRepository
    {
        List<BoatModel> GetBoats();
        List<CustomerModel> GetCustomers();
        string CreateNewBoat(BoatModel boat);

        string BookBoatForCustomer(int BoatId, int CustId, int NoOfHours);
    }
}
