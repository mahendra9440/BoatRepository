﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BoatRental
{
    public class BoatModel
    {
        public BoatModel()
        {

        }
        public int BoatId { get; set; }
        public string BoatName{get;set;}
        public int HourlyAmount { get; set; }
    }
}
